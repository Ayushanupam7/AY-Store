import { apps, reviews, categories, users, type App, type InsertApp, type Review, type InsertReview, type Category, type InsertCategory, type User, type InsertUser } from "@shared/schema";
import { db } from "./db";
import { eq, desc, like, or } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Apps
  getAllApps(): Promise<App[]>;
  getApp(id: number): Promise<App | undefined>;
  createApp(app: InsertApp): Promise<App>;
  updateApp(id: number, app: Partial<InsertApp>): Promise<App | undefined>;
  deleteApp(id: number): Promise<boolean>;
  getAppsByCategory(category: string): Promise<App[]>;
  getFeaturedApps(): Promise<App[]>;
  getTopApps(limit?: number): Promise<App[]>;
  getEditorChoiceApps(): Promise<App[]>;
  searchApps(query: string): Promise<App[]>;
  
  // Reviews
  getReviewsForApp(appId: number): Promise<Review[]>;
  createReview(review: InsertReview): Promise<Review>;
  updateReviewHelpfulCount(reviewId: number): Promise<Review | undefined>;
  
  // Categories
  getAllCategories(): Promise<Category[]>;
  createCategory(category: InsertCategory): Promise<Category>;
}

export class DatabaseStorage implements IStorage {
  constructor() {
    // Initialize default data when the database is first set up
    this.initializeDefaultData();
  }

  private async initializeDefaultData() {
    try {
      // Check if categories already exist
      const existingCategories = await db.select().from(categories).limit(1);
      if (existingCategories.length > 0) return;

      // Insert default categories
      await this.initializeDefaultCategories();
      // Insert default apps
      await this.initializeDefaultApps();
    } catch (error) {
      console.log("Database initialization will happen on first request");
    }
  }

  private async initializeDefaultCategories() {
    const defaultCategories = [
      { name: "Games", icon: "fas fa-gamepad", color: "text-primary" },
      { name: "Business", icon: "fas fa-briefcase", color: "text-secondary" },
      { name: "Photo", icon: "fas fa-camera", color: "text-accent" },
      { name: "Education", icon: "fas fa-graduation-cap", color: "text-purple-500" },
      { name: "Health", icon: "fas fa-heartbeat", color: "text-green-500" },
      { name: "Music", icon: "fas fa-music", color: "text-yellow-500" },
    ];

    try {
      await db.insert(categories).values(defaultCategories);
    } catch (error) {
      console.log("Categories may already exist:", error);
    }
  }

  private async initializeDefaultApps() {
    const defaultApps = [
      {
        name: "TaskMaster Pro",
        developer: "Productivity Studios",
        category: "Business",
        description: "Boost your productivity with our advanced task management features and seamless collaboration tools.",
        price: "0.00",
        isFree: true,
        downloads: 100000,
        rating: "4.5",
        reviewCount: 1234,
        isEditorChoice: false,
        isFeatured: true,
      },
      {
        name: "Adventure Quest",
        developer: "Epic Games Studio",
        category: "Games",
        description: "Embark on an epic adventure in this stunning open-world RPG with immersive gameplay.",
        price: "0.00",
        isFree: true,
        downloads: 500000,
        rating: "4.8",
        reviewCount: 2567,
        isEditorChoice: false,
        isFeatured: false,
      },
      {
        name: "PhotoEdit Plus",
        developer: "Creative Media Inc",
        category: "Photo",
        description: "Professional photo editing tools with AI-powered filters and advanced editing capabilities.",
        price: "4.99",
        isFree: false,
        downloads: 75000,
        rating: "4.2",
        reviewCount: 890,
        isEditorChoice: false,
        isFeatured: false,
      },
      {
        name: "Music Stream",
        developer: "Audio Tech",
        category: "Music",
        description: "Stream millions of songs with high-quality audio and personalized playlists.",
        price: "0.00",
        isFree: true,
        downloads: 250000,
        rating: "4.6",
        reviewCount: 1456,
        isEditorChoice: false,
        isFeatured: false,
      },
      {
        name: "Mindful Meditation",
        developer: "Wellness & Health",
        category: "Health",
        description: "Start your journey to inner peace with guided meditations, breathing exercises, and mindfulness practices designed by experts.",
        price: "0.00",
        isFree: true,
        downloads: 1000000,
        rating: "4.9",
        reviewCount: 3421,
        isEditorChoice: true,
        isFeatured: false,
      },
    ];

    try {
      const insertedApps = await db.insert(apps).values(defaultApps).returning();
      // Add some default reviews for the first app
      if (insertedApps.length > 0) {
        await this.initializeDefaultReviews(insertedApps[0].id);
      }
    } catch (error) {
      console.log("Apps may already exist:", error);
    }
  }

  private async initializeDefaultReviews(appId: number) {
    const defaultReviews = [
      {
        appId,
        authorName: "John Doe",
        rating: 5,
        content: "This app has completely transformed how I manage my daily tasks. The interface is clean and intuitive, and the collaboration features are fantastic. Highly recommend!",
      },
      {
        appId,
        authorName: "Sarah Miller",
        rating: 4,
        content: "Great app overall! Love the task organization features. Could use some improvements in the notification system, but definitely worth downloading.",
      },
    ];

    try {
      await db.insert(reviews).values(defaultReviews);
    } catch (error) {
      console.log("Reviews may already exist:", error);
    }
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  // App methods
  async getAllApps(): Promise<App[]> {
    return await db.select().from(apps);
  }

  async getApp(id: number): Promise<App | undefined> {
    const [app] = await db.select().from(apps).where(eq(apps.id, id));
    return app || undefined;
  }

  async createApp(insertApp: InsertApp): Promise<App> {
    const [app] = await db
      .insert(apps)
      .values(insertApp)
      .returning();
    return app;
  }

  async updateApp(id: number, updateData: Partial<InsertApp>): Promise<App | undefined> {
    const [app] = await db
      .update(apps)
      .set(updateData)
      .where(eq(apps.id, id))
      .returning();
    return app || undefined;
  }

  async deleteApp(id: number): Promise<boolean> {
    const result = await db.delete(apps).where(eq(apps.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getAppsByCategory(category: string): Promise<App[]> {
    return await db.select().from(apps).where(eq(apps.category, category));
  }

  async getFeaturedApps(): Promise<App[]> {
    return await db.select().from(apps).where(eq(apps.isFeatured, true));
  }

  async getTopApps(limit = 10): Promise<App[]> {
    return await db
      .select()
      .from(apps)
      .orderBy(desc(apps.rating))
      .limit(limit);
  }

  async getEditorChoiceApps(): Promise<App[]> {
    return await db.select().from(apps).where(eq(apps.isEditorChoice, true));
  }

  async searchApps(query: string): Promise<App[]> {
    const searchPattern = `%${query.toLowerCase()}%`;
    return await db
      .select()
      .from(apps)
      .where(
        or(
          like(apps.name, searchPattern),
          like(apps.developer, searchPattern),
          like(apps.description, searchPattern),
          like(apps.category, searchPattern)
        )
      );
  }

  // Review methods
  async getReviewsForApp(appId: number): Promise<Review[]> {
    return await db
      .select()
      .from(reviews)
      .where(eq(reviews.appId, appId))
      .orderBy(desc(reviews.createdAt));
  }

  async createReview(insertReview: InsertReview): Promise<Review> {
    const [review] = await db
      .insert(reviews)
      .values(insertReview)
      .returning();

    // Update app rating and review count
    await this.updateAppRating(insertReview.appId);
    
    return review;
  }

  async updateReviewHelpfulCount(reviewId: number): Promise<Review | undefined> {
    // First get the current review to get its current helpful count
    const [currentReview] = await db.select().from(reviews).where(eq(reviews.id, reviewId));
    if (!currentReview) return undefined;

    const newHelpfulCount = (currentReview.helpfulCount ?? 0) + 1;
    
    const [updatedReview] = await db
      .update(reviews)
      .set({ helpfulCount: newHelpfulCount })
      .where(eq(reviews.id, reviewId))
      .returning();
    return updatedReview || undefined;
  }

  private async updateAppRating(appId: number): Promise<void> {
    const appReviews = await this.getReviewsForApp(appId);
    if (appReviews.length === 0) return;

    const totalRating = appReviews.reduce((sum, review) => sum + review.rating, 0);
    const averageRating = (totalRating / appReviews.length).toFixed(2);

    await db
      .update(apps)
      .set({
        rating: averageRating,
        reviewCount: appReviews.length,
      })
      .where(eq(apps.id, appId));
  }

  // Category methods
  async getAllCategories(): Promise<Category[]> {
    return await db.select().from(categories);
  }

  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const [category] = await db
      .insert(categories)
      .values(insertCategory)
      .returning();
    return category;
  }
}

export const storage = new DatabaseStorage();