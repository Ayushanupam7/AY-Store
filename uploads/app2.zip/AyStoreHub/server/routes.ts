import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertAppSchema, insertReviewSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all apps
  app.get("/api/apps", async (req, res) => {
    try {
      const apps = await storage.getAllApps();
      res.json(apps);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch apps" });
    }
  });

  // Get featured apps (must come before /api/apps/:id)
  app.get("/api/apps/featured", async (req, res) => {
    try {
      const apps = await storage.getFeaturedApps();
      res.json(apps);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch featured apps" });
    }
  });

  // Get top apps (must come before /api/apps/:id)
  app.get("/api/apps/top", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const apps = await storage.getTopApps(limit);
      res.json(apps);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch top apps" });
    }
  });

  // Get editor's choice apps (must come before /api/apps/:id)
  app.get("/api/apps/editors-choice", async (req, res) => {
    try {
      const apps = await storage.getEditorChoiceApps();
      res.json(apps);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch editor's choice apps" });
    }
  });

  // Search apps (must come before /api/apps/:id)
  app.get("/api/apps/search", async (req, res) => {
    try {
      const query = req.query.q as string;
      if (!query) {
        return res.status(400).json({ message: "Search query is required" });
      }
      const apps = await storage.searchApps(query);
      res.json(apps);
    } catch (error) {
      res.status(500).json({ message: "Failed to search apps" });
    }
  });

  // Get apps by category (must come before /api/apps/:id)
  app.get("/api/apps/category/:category", async (req, res) => {
    try {
      const category = req.params.category;
      const apps = await storage.getAppsByCategory(category);
      res.json(apps);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch apps by category" });
    }
  });

  // Get app by ID (must come after specific routes)
  app.get("/api/apps/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const app = await storage.getApp(id);
      if (!app) {
        return res.status(404).json({ message: "App not found" });
      }
      res.json(app);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch app" });
    }
  });

  // Create new app (admin)
  app.post("/api/apps", async (req, res) => {
    try {
      const validatedData = insertAppSchema.parse(req.body);
      const app = await storage.createApp(validatedData);
      res.status(201).json(app);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid app data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create app" });
    }
  });

  // Update app (admin)
  app.patch("/api/apps/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const validatedData = insertAppSchema.partial().parse(req.body);
      const app = await storage.updateApp(id, validatedData);
      if (!app) {
        return res.status(404).json({ message: "App not found" });
      }
      res.json(app);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid app data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update app" });
    }
  });

  // Delete app (admin)
  app.delete("/api/apps/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteApp(id);
      if (!deleted) {
        return res.status(404).json({ message: "App not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete app" });
    }
  });

  // Get reviews for an app
  app.get("/api/apps/:id/reviews", async (req, res) => {
    try {
      const appId = parseInt(req.params.id);
      const reviews = await storage.getReviewsForApp(appId);
      res.json(reviews);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch reviews" });
    }
  });

  // Create review for an app
  app.post("/api/apps/:id/reviews", async (req, res) => {
    try {
      const appId = parseInt(req.params.id);
      const reviewData = { ...req.body, appId };
      const validatedData = insertReviewSchema.parse(reviewData);
      const review = await storage.createReview(validatedData);
      res.status(201).json(review);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid review data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create review" });
    }
  });

  // Mark review as helpful
  app.patch("/api/reviews/:id/helpful", async (req, res) => {
    try {
      const reviewId = parseInt(req.params.id);
      const review = await storage.updateReviewHelpfulCount(reviewId);
      if (!review) {
        return res.status(404).json({ message: "Review not found" });
      }
      res.json(review);
    } catch (error) {
      res.status(500).json({ message: "Failed to update review" });
    }
  });

  // Get all categories
  app.get("/api/categories", async (req, res) => {
    try {
      const categories = await storage.getAllCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
