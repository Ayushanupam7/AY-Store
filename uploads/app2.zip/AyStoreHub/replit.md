# AY Store - Mobile App Store Platform

## Overview

AY Store is a full-stack web application that mimics a mobile app store interface. It provides a platform for browsing, discovering, and managing mobile applications with features like app listings, reviews, categories, and administrative controls. The application is built with a modern React frontend and Express.js backend, using PostgreSQL for data persistence.

## System Architecture

The application follows a **monorepo structure** with clear separation between client and server code:

- **Frontend**: React with TypeScript, using Vite as the build tool
- **Backend**: Express.js with TypeScript for API services
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **UI Framework**: Tailwind CSS with shadcn/ui components for consistent design
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for lightweight client-side routing

The architecture supports both development and production environments with proper build processes and static file serving.

## Key Components

### Frontend Architecture
- **Component-based design** using React functional components with hooks
- **Responsive UI** with mobile-first approach using Tailwind CSS
- **Type-safe development** with TypeScript throughout
- **Modern UI components** from shadcn/ui library (Radix UI primitives)
- **Form handling** with React Hook Form and Zod validation
- **Toast notifications** for user feedback

### Backend Architecture
- **RESTful API** design with Express.js
- **Type-safe database operations** using Drizzle ORM
- **Shared schema definitions** between client and server
- **Request/response logging** middleware for debugging
- **Error handling** with proper HTTP status codes
- **Static file serving** for production builds

### Database Schema
The application uses four main entities:
- **Apps**: Core app information including metadata, ratings, and download counts
- **Reviews**: User reviews with ratings and helpfulness tracking
- **Categories**: App categorization with icons and colors
- **Users**: User management (schema defined but not fully implemented)

## Data Flow

1. **Client Requests**: React components use TanStack Query to fetch data from API endpoints
2. **API Processing**: Express routes handle requests, validate data using Zod schemas
3. **Database Operations**: Drizzle ORM executes type-safe database queries
4. **Response Handling**: JSON responses are sent back to client with proper error handling
5. **State Updates**: TanStack Query manages caching and automatic refetching

The application supports real-time updates through query invalidation when data changes (e.g., after creating reviews or apps).

## External Dependencies

### Core Technologies
- **React 18** with TypeScript for frontend development
- **Express.js** for backend API server
- **PostgreSQL** with Neon Database as the cloud provider
- **Drizzle ORM** for database operations and migrations

### UI and Styling
- **Tailwind CSS** for utility-first styling
- **Radix UI** primitives for accessible components
- **Lucide React** for consistent iconography
- **Class Variance Authority** for component variant management

### Development Tools
- **Vite** for fast development and optimized builds
- **TypeScript** for type safety across the stack
- **ESBuild** for backend bundling in production
- **Replit integration** with development banner and cartographer

## Deployment Strategy

The application uses a **unified deployment approach**:

1. **Development**: 
   - Vite dev server for frontend with HMR
   - tsx for running TypeScript backend directly
   - Both services run concurrently

2. **Production**:
   - Frontend built using Vite and served as static files
   - Backend bundled with ESBuild for Node.js execution
   - Single Express server serves both API and static content

3. **Database**:
   - PostgreSQL hosted on Neon Database
   - Migrations managed through Drizzle Kit
   - Connection via DATABASE_URL environment variable

The build process creates a single deployable artifact that can run on any Node.js hosting platform.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes

- **July 05, 2025** - Database Integration Complete
  - Added PostgreSQL database with Drizzle ORM
  - Created database schema with apps, reviews, categories, and users tables
  - Replaced in-memory storage with persistent database storage
  - Added database initialization with default data
  - Fixed API routing issues for better endpoint handling
  - All CRUD operations now persist to database

## Changelog

- July 05, 2025 - Initial setup with in-memory storage
- July 05, 2025 - Database integration and persistent storage implementation