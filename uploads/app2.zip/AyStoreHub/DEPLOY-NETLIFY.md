# Deploy AY Store to Netlify

## Prerequisites

1. **Database Setup**: You need a cloud PostgreSQL database. I recommend using Neon, Supabase, or Railway.
2. **GitHub Repository**: Push your code to GitHub first.
3. **Netlify Account**: Sign up at netlify.com

## Option 1: Static Export (Recommended for Netlify)

Since Netlify is primarily for static sites, the best approach is to build a static version of the frontend and use a separate service for the backend API.

### Step 1: Prepare for Static Build

1. **Update the frontend to use external API**:
   
   In `client/src/lib/queryClient.ts`, update the base URL:
   ```typescript
   // Change from relative URLs to your backend service URL
   const API_BASE = import.meta.env.VITE_API_URL || 'https://your-backend-service.com';
   
   export async function apiRequest(
     method: string,
     endpoint: string,
     data?: any
   ): Promise<any> {
     const url = `${API_BASE}${endpoint}`;
     // ... rest of the function
   }
   ```

2. **Create environment file** `.env`:
   ```
   VITE_API_URL=https://your-backend-api-url.com
   ```

3. **Build the frontend**:
   ```bash
   npm run build
   ```

4. **Deploy to Netlify**:
   - Go to netlify.com and connect your GitHub repository
   - Set build command: `npm run build`
   - Set publish directory: `dist/public`
   - Add environment variable: `VITE_API_URL=your-backend-url`

### Step 2: Deploy Backend Separately

Deploy your backend to one of these platforms:

**Railway (Recommended)**:
1. Go to railway.app
2. Connect your GitHub repo
3. Add PostgreSQL database
4. Set environment variables: `DATABASE_URL` from Railway
5. Deploy automatically

**Render**:
1. Go to render.com
2. Create new Web Service from GitHub
3. Add PostgreSQL database
4. Set build command: `npm run build`
5. Set start command: `npm start`

**Heroku**:
1. Install Heroku CLI
2. Create app: `heroku create your-app-name`
3. Add PostgreSQL: `heroku addons:create heroku-postgresql:mini`
4. Deploy: `git push heroku main`

## Option 2: Netlify Functions (Current Setup)

I've already prepared the files for Netlify Functions. Here's how to deploy:

### Step 1: Environment Variables

In Netlify dashboard, add these environment variables:
- `DATABASE_URL` - Your PostgreSQL connection string
- `NODE_ENV` - Set to "production"

### Step 2: Deploy

1. **Push to GitHub** first:
   ```bash
   git add .
   git commit -m "Add Netlify deployment config"
   git push origin main
   ```

2. **Connect to Netlify**:
   - Go to netlify.com
   - Click "New site from Git"
   - Choose your GitHub repository
   - Build settings should auto-detect from `netlify.toml`
   - Click "Deploy site"

3. **Configure Database**:
   - Make sure your PostgreSQL database allows connections from Netlify's servers
   - Run database migration: `npm run db:push` (you might need to do this locally first)

### Step 3: Test Deployment

After deployment:
1. Visit your Netlify URL
2. Test the admin panel by adding a new app
3. Check if data persists by refreshing the page

## Database Setup Options

### Option A: Neon (Recommended)
1. Go to neon.tech
2. Create a new project
3. Copy the connection string
4. Use it as your `DATABASE_URL`

### Option B: Supabase
1. Go to supabase.com
2. Create a new project
3. Go to Settings > Database
4. Copy the connection string
5. Replace `[YOUR-PASSWORD]` with your actual password

### Option C: Railway
1. Go to railway.app
2. Create new project
3. Add PostgreSQL
4. Copy the `DATABASE_URL` from variables

## Troubleshooting

### Common Issues:

1. **Database Connection Errors**:
   - Ensure `DATABASE_URL` is correctly set in Netlify environment variables
   - Check if your database allows external connections

2. **API Routes Not Working**:
   - Verify that `netlify.toml` is in the root directory
   - Check Netlify function logs for errors

3. **Build Failures**:
   - Ensure all dependencies are listed in `package.json`
   - Check that TypeScript compiles without errors

4. **CORS Issues**:
   - The Netlify function includes CORS headers
   - If using external backend, ensure CORS is properly configured

## Environment Variables Needed

```
DATABASE_URL=postgresql://user:password@host:port/database
NODE_ENV=production
VITE_API_URL=https://your-netlify-site.netlify.app/.netlify/functions/api
```

## Build Commands

- **Build Command**: `npm run build` (for static) or `vite build` (auto-detected)
- **Functions Directory**: `netlify/functions`
- **Publish Directory**: `dist/public` (for static) or `dist/client` (for functions)

## Final Notes

- The Netlify Functions approach will work but has cold start delays
- For better performance, consider using Railway/Render for the backend and Netlify for frontend only
- Make sure to run `npm run db:push` to create database tables before first use