import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { ArrowLeft, Star, Download, Tag, Info, ThumbsUp, Flag } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { App, Review } from "@shared/schema";

export default function AppDetail() {
  const [, params] = useRoute("/app/:id");
  const appId = parseInt(params?.id || "0");
  const { toast } = useToast();
  
  const [reviewText, setReviewText] = useState("");
  const [reviewRating, setReviewRating] = useState(5);
  const [authorName, setAuthorName] = useState("");

  const { data: app, isLoading: appLoading } = useQuery<App>({
    queryKey: ["/api/apps", appId],
  });

  const { data: reviews = [], isLoading: reviewsLoading } = useQuery<Review[]>({
    queryKey: ["/api/apps", appId, "reviews"],
  });

  const createReviewMutation = useMutation({
    mutationFn: async (reviewData: { authorName: string; rating: number; content: string }) => {
      return apiRequest("POST", `/api/apps/${appId}/reviews`, reviewData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/apps", appId, "reviews"] });
      queryClient.invalidateQueries({ queryKey: ["/api/apps", appId] });
      setReviewText("");
      setAuthorName("");
      setReviewRating(5);
      toast({
        title: "Review submitted",
        description: "Thank you for your feedback!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to submit review. Please try again.",
        variant: "destructive",
      });
    },
  });

  const markHelpfulMutation = useMutation({
    mutationFn: async (reviewId: number) => {
      return apiRequest("PATCH", `/api/reviews/${reviewId}/helpful`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/apps", appId, "reviews"] });
    },
  });

  if (appLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-lg">Loading...</div>
      </div>
    );
  }

  if (!app) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="text-lg font-semibold mb-2">App not found</div>
          <Button onClick={() => window.history.back()}>Go Back</Button>
        </div>
      </div>
    );
  }

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!authorName.trim() || !reviewText.trim()) {
      toast({
        title: "Error",
        description: "Please fill in all fields",
        variant: "destructive",
      });
      return;
    }
    
    createReviewMutation.mutate({
      authorName: authorName.trim(),
      rating: reviewRating,
      content: reviewText.trim(),
    });
  };

  const getRatingStars = (rating: number) => {
    return [...Array(5)].map((_, i) => (
      <Star
        key={i}
        className={`h-4 w-4 ${
          i < rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
        }`}
      />
    ));
  };

  const getRatingDistribution = () => {
    const distribution = [0, 0, 0, 0, 0];
    reviews.forEach(review => {
      if (review.rating >= 1 && review.rating <= 5) {
        distribution[review.rating - 1]++;
      }
    });
    return distribution.reverse();
  };

  const ratingDistribution = getRatingDistribution();
  const totalReviews = reviews.length;

  return (
    <div className="min-h-screen bg-neutral-50">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center h-16">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => window.history.back()}
              className="mr-4"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
            <h1 className="text-lg font-semibold truncate">{app.name}</h1>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {/* App Header */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <div className="flex items-start">
              <div className="w-24 h-24 bg-gradient-to-br from-blue-500 to-purple-600 rounded-3xl flex items-center justify-center mr-6 flex-shrink-0">
                <i className="fas fa-mobile-alt text-white text-3xl"></i>
              </div>
              <div className="flex-1">
                <h2 className="text-2xl font-bold mb-2">{app.name}</h2>
                <p className="text-gray-600 mb-3">{app.developer}</p>
                <div className="flex items-center mb-4">
                  <div className="flex text-yellow-400 text-lg mr-3">
                    {getRatingStars(Math.floor(parseFloat(app.rating)))}
                  </div>
                  <span className="text-lg font-bold mr-2">{app.rating}</span>
                  <span className="text-gray-600">({app.reviewCount} reviews)</span>
                </div>
                <div className="flex items-center space-x-6 text-sm text-gray-600">
                  <div className="flex items-center">
                    <Download className="h-4 w-4 mr-1" />
                    <span>{app.downloads.toLocaleString()}+ downloads</span>
                  </div>
                  <div className="flex items-center">
                    <Tag className="h-4 w-4 mr-1" />
                    <span>{app.category}</span>
                  </div>
                  <div className="flex items-center">
                    <Info className="h-4 w-4 mr-1" />
                    <span>Rated for Everyone</span>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold text-green-600 mb-2">
                  {app.isFree ? "FREE" : `$${app.price}`}
                </div>
                <Button size="lg" className="bg-primary text-white hover:bg-primary-dark">
                  {app.isFree ? "Install" : "Buy"}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Description */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <h3 className="text-lg font-bold mb-3">About this app</h3>
            <p className="text-gray-700 leading-relaxed">{app.description}</p>
          </CardContent>
        </Card>

        {/* Reviews Section */}
        <Card>
          <CardContent className="p-6">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-lg font-bold">Ratings and reviews</h3>
            </div>

            {/* Rating Overview */}
            {reviews.length > 0 && (
              <div className="bg-gray-50 rounded-xl p-6 mb-6">
                <div className="flex items-center">
                  <div className="text-center mr-8">
                    <div className="text-4xl font-bold">{app.rating}</div>
                    <div className="flex text-yellow-400 text-lg justify-center mb-1">
                      {getRatingStars(Math.floor(parseFloat(app.rating)))}
                    </div>
                    <div className="text-sm text-gray-600">{totalReviews} reviews</div>
                  </div>
                  <div className="flex-1">
                    {ratingDistribution.map((count, index) => (
                      <div key={index} className="flex items-center mb-2">
                        <span className="text-sm w-6">{5 - index}</span>
                        <div className="flex-1 mx-3 bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-primary h-2 rounded-full"
                            style={{
                              width: totalReviews > 0 ? `${(count / totalReviews) * 100}%` : "0%",
                            }}
                          ></div>
                        </div>
                        <span className="text-sm text-gray-600 w-12">{count}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Write Review Form */}
            <div className="mb-8 p-4 bg-gray-50 rounded-lg">
              <h4 className="font-semibold mb-4">Write a review</h4>
              <form onSubmit={handleSubmitReview} className="space-y-4">
                <div>
                  <Label htmlFor="authorName">Your Name</Label>
                  <input
                    id="authorName"
                    type="text"
                    value={authorName}
                    onChange={(e) => setAuthorName(e.target.value)}
                    className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                    placeholder="Enter your name"
                    required
                  />
                </div>
                <div>
                  <Label>Rating</Label>
                  <div className="flex space-x-1 mt-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setReviewRating(star)}
                        className="p-1"
                      >
                        <Star
                          className={`h-6 w-6 ${
                            star <= reviewRating
                              ? "fill-yellow-400 text-yellow-400"
                              : "text-gray-300"
                          }`}
                        />
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <Label htmlFor="reviewText">Review</Label>
                  <Textarea
                    id="reviewText"
                    value={reviewText}
                    onChange={(e) => setReviewText(e.target.value)}
                    placeholder="Share your experience with this app..."
                    rows={4}
                    required
                  />
                </div>
                <Button
                  type="submit"
                  disabled={createReviewMutation.isPending}
                  className="bg-primary hover:bg-primary-dark"
                >
                  {createReviewMutation.isPending ? "Submitting..." : "Submit Review"}
                </Button>
              </form>
            </div>

            {/* Individual Reviews */}
            {reviewsLoading ? (
              <div className="text-center py-4">Loading reviews...</div>
            ) : reviews.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                No reviews yet. Be the first to review this app!
              </div>
            ) : (
              <div className="space-y-6">
                {reviews.map((review) => (
                  <div key={review.id} className="border-b border-gray-200 pb-6">
                    <div className="flex items-start">
                      <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center mr-4 flex-shrink-0">
                        <span className="text-white font-bold text-sm">
                          {review.authorName.charAt(0).toUpperCase()}
                        </span>
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center mb-2">
                          <h4 className="font-medium mr-3">{review.authorName}</h4>
                          <div className="flex text-yellow-400 text-sm">
                            {getRatingStars(review.rating)}
                          </div>
                        </div>
                        <p className="text-sm text-gray-600 mb-2">
                          {review.createdAt.toLocaleDateString()}
                        </p>
                        <p className="text-gray-700 mb-3">{review.content}</p>
                        <div className="flex items-center space-x-4">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => markHelpfulMutation.mutate(review.id)}
                            disabled={markHelpfulMutation.isPending}
                            className="text-gray-500 hover:text-gray-700"
                          >
                            <ThumbsUp className="h-4 w-4 mr-1" />
                            Helpful ({review.helpfulCount})
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-gray-500 hover:text-gray-700"
                          >
                            <Flag className="h-4 w-4 mr-1" />
                            Report
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
