import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Search, Plus, Menu, X } from "lucide-react";
import Header from "@/components/header";
import AdminModal from "@/components/admin-modal";
import AppCard from "@/components/app-card";
import BottomNav from "@/components/bottom-nav";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import type { App, Category } from "@shared/schema";

export default function Home() {
  const [isAdminModalOpen, setIsAdminModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const { data: apps = [], isLoading: appsLoading } = useQuery<App[]>({
    queryKey: ["/api/apps"],
  });

  const { data: categories = [], isLoading: categoriesLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const { data: featuredApps = [] } = useQuery<App[]>({
    queryKey: ["/api/apps/featured"],
  });

  const { data: topApps = [] } = useQuery<App[]>({
    queryKey: ["/api/apps/top"],
  });

  const { data: editorChoiceApps = [] } = useQuery<App[]>({
    queryKey: ["/api/apps/editors-choice"],
  });

  const { data: searchResults = [] } = useQuery<App[]>({
    queryKey: ["/api/apps/search", { q: searchQuery }],
    enabled: searchQuery.length > 0,
  });

  const { data: categoryApps = [] } = useQuery<App[]>({
    queryKey: ["/api/apps/category", selectedCategory],
    enabled: !!selectedCategory,
  });

  const getDisplayApps = () => {
    if (searchQuery) return searchResults;
    if (selectedCategory) return categoryApps;
    return topApps;
  };

  const displayApps = getDisplayApps();

  const featuredApp = featuredApps[0];

  if (appsLoading || categoriesLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-lg">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-50">
      <Header onOpenAdmin={() => setIsAdminModalOpen(true)} />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 pb-mobile-nav md:pb-6">
        {/* Search Bar - Mobile */}
        <div className="sm:hidden mb-6">
          <div className="relative">
            <Input
              type="text"
              placeholder="Search apps & games"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
          </div>
        </div>

        {/* Hero Section */}
        {!searchQuery && !selectedCategory && featuredApp && (
          <section className="mb-8">
            <Card className="bg-gradient-to-r from-primary to-blue-600 text-white border-0 overflow-hidden">
              <CardContent className="p-6 md:p-8">
                <div className="flex flex-col md:flex-row items-center">
                  <div className="flex-1 mb-6 md:mb-0 md:mr-8">
                    <h2 className="text-2xl md:text-3xl font-bold mb-2">Featured App of the Week</h2>
                    <p className="text-blue-100 mb-4">{featuredApp.name} - {featuredApp.description}</p>
                    <Button 
                      className="bg-white text-primary hover:bg-gray-100"
                      onClick={() => window.location.href = `/app/${featuredApp.id}`}
                    >
                      Learn More
                    </Button>
                  </div>
                  <div className="flex-shrink-0">
                    <div className="w-48 h-64 bg-white bg-opacity-20 rounded-3xl p-4 backdrop-blur-sm">
                      <div className="w-full h-full bg-white bg-opacity-30 rounded-2xl flex flex-col items-center justify-center">
                        <i className="fas fa-mobile-alt text-6xl text-white mb-4"></i>
                        <div className="text-center">
                          <div className="text-sm font-medium">AY Store</div>
                          <div className="text-xs opacity-75">Your Apps</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </section>
        )}

        {/* Categories Section */}
        {!searchQuery && (
          <section className="mb-8">
            <h3 className="text-xl font-bold mb-4">Browse by Category</h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {categories.map((category) => (
                <Card 
                  key={category.id} 
                  className={`cursor-pointer hover:shadow-lg transition-shadow ${
                    selectedCategory === category.name ? 'ring-2 ring-primary' : ''
                  }`}
                  onClick={() => setSelectedCategory(
                    selectedCategory === category.name ? null : category.name
                  )}
                >
                  <CardContent className="p-4 text-center">
                    <div className="w-12 h-12 bg-primary bg-opacity-10 rounded-xl flex items-center justify-center mx-auto mb-3">
                      <i className={`${category.icon} text-xl text-primary`}></i>
                    </div>
                    <span className="text-sm font-medium text-neutral-900">{category.name}</span>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>
        )}

        {/* Apps Section */}
        <section className="mb-8">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-xl font-bold">
              {searchQuery ? `Search Results for "${searchQuery}"` : 
               selectedCategory ? `${selectedCategory} Apps` : 
               'Top Free Apps'}
            </h3>
            {!searchQuery && !selectedCategory && (
              <Button variant="ghost" className="text-primary hover:text-primary-dark">
                See all <i className="fas fa-arrow-right ml-1"></i>
              </Button>
            )}
          </div>
          
          {displayApps.length === 0 ? (
            <div className="text-center py-12">
              <div className="text-gray-500 mb-2">No apps found</div>
              {searchQuery && (
                <div className="text-sm text-gray-400">Try searching with different keywords</div>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {displayApps.map((app) => (
                <AppCard key={app.id} app={app} />
              ))}
            </div>
          )}
        </section>

        {/* Editor's Choice Section */}
        {!searchQuery && !selectedCategory && editorChoiceApps.length > 0 && (
          <section className="mb-8">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold">Editor's Choice</h3>
              <Button variant="ghost" className="text-primary hover:text-primary-dark">
                See all <i className="fas fa-arrow-right ml-1"></i>
              </Button>
            </div>
            
            {editorChoiceApps.map((app) => (
              <Card key={app.id} className="hover:shadow-lg transition-shadow cursor-pointer" 
                    onClick={() => window.location.href = `/app/${app.id}`}>
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row items-start md:items-center">
                    <div className="w-20 h-20 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl flex items-center justify-center mr-6 mb-4 md:mb-0 flex-shrink-0">
                      <i className="fas fa-award text-white text-3xl"></i>
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center mb-2">
                        <span className="bg-accent text-white px-3 py-1 rounded-full text-xs font-bold mr-3">
                          EDITOR'S CHOICE
                        </span>
                        <div className="flex text-yellow-400 text-sm">
                          {[...Array(5)].map((_, i) => (
                            <i key={i} className={`fas fa-star${i < Math.floor(parseFloat(app.rating)) ? '' : '-o'}`}></i>
                          ))}
                        </div>
                      </div>
                      <h4 className="text-xl font-bold mb-2">{app.name}</h4>
                      <p className="text-gray-600 mb-3">{app.developer} • {app.rating} ★ • {app.downloads.toLocaleString()}+ downloads</p>
                      <p className="text-gray-700 mb-4 line-clamp-2">{app.description}</p>
                      <Button 
                        className="bg-primary text-white hover:bg-primary-dark"
                        onClick={(e) => {
                          e.stopPropagation();
                          // Handle install
                        }}
                      >
                        Install
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </section>
        )}
      </main>

      <BottomNav />

      {/* Floating Action Button */}
      <Button
        size="lg"
        className="fixed bottom-20 md:bottom-6 right-6 w-14 h-14 rounded-full shadow-lg hover:shadow-xl bg-primary hover:bg-primary-dark z-30"
        onClick={() => setIsAdminModalOpen(true)}
      >
        <Plus className="h-6 w-6" />
      </Button>

      <AdminModal
        isOpen={isAdminModalOpen}
        onClose={() => setIsAdminModalOpen(false)}
      />
    </div>
  );
}
