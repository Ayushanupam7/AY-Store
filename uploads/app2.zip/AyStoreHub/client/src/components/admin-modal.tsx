import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { X, Upload, FileArchive } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { InsertApp } from "@shared/schema";

interface AdminModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function AdminModal({ isOpen, onClose }: AdminModalProps) {
  const { toast } = useToast();
  const [formData, setFormData] = useState<Partial<InsertApp>>({
    name: "",
    developer: "",
    category: "",
    description: "",
    price: "0.00",
    isFree: true,
    isEditorChoice: false,
    isFeatured: false,
  });

  const createAppMutation = useMutation({
    mutationFn: async (appData: InsertApp) => {
      return apiRequest("POST", "/api/apps", appData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/apps"] });
      queryClient.invalidateQueries({ queryKey: ["/api/apps/top"] });
      queryClient.invalidateQueries({ queryKey: ["/api/apps/featured"] });
      queryClient.invalidateQueries({ queryKey: ["/api/apps/editors-choice"] });
      toast({
        title: "Success!",
        description: "App has been added successfully.",
      });
      setFormData({
        name: "",
        developer: "",
        category: "",
        description: "",
        price: "0.00",
        isFree: true,
        isEditorChoice: false,
        isFeatured: false,
      });
      onClose();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add app. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name || !formData.developer || !formData.category || !formData.description) {
      toast({
        title: "Error",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    createAppMutation.mutate(formData as InsertApp);
  };

  const handleInputChange = (field: keyof InsertApp, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="p-6 border-b border-gray-200">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold">Admin Panel</h2>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="h-5 w-5" />
            </Button>
          </div>
        </div>
        
        <div className="p-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <Label htmlFor="name">App Name *</Label>
              <Input
                id="name"
                type="text"
                value={formData.name || ""}
                onChange={(e) => handleInputChange("name", e.target.value)}
                placeholder="Enter app name"
                required
              />
            </div>
            
            <div>
              <Label htmlFor="developer">Developer *</Label>
              <Input
                id="developer"
                type="text"
                value={formData.developer || ""}
                onChange={(e) => handleInputChange("developer", e.target.value)}
                placeholder="Developer name"
                required
              />
            </div>
            
            <div>
              <Label htmlFor="category">Category *</Label>
              <Select
                value={formData.category || ""}
                onValueChange={(value) => handleInputChange("category", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Games">Games</SelectItem>
                  <SelectItem value="Business">Business</SelectItem>
                  <SelectItem value="Photo">Photo</SelectItem>
                  <SelectItem value="Education">Education</SelectItem>
                  <SelectItem value="Health">Health</SelectItem>
                  <SelectItem value="Music">Music</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label htmlFor="description">Description *</Label>
              <Textarea
                id="description"
                value={formData.description || ""}
                onChange={(e) => handleInputChange("description", e.target.value)}
                placeholder="App description..."
                rows={4}
                required
              />
            </div>
            
            <div>
              <Label>Price</Label>
              <RadioGroup
                value={formData.isFree ? "free" : "paid"}
                onValueChange={(value) => {
                  const isFree = value === "free";
                  handleInputChange("isFree", isFree);
                  if (isFree) {
                    handleInputChange("price", "0.00");
                  }
                }}
                className="flex items-center space-x-4 mt-2"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="free" id="free" />
                  <Label htmlFor="free">Free</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="paid" id="paid" />
                  <Label htmlFor="paid">Paid</Label>
                </div>
              </RadioGroup>
              {!formData.isFree && (
                <Input
                  type="number"
                  step="0.01"
                  min="0"
                  value={formData.price || ""}
                  onChange={(e) => handleInputChange("price", e.target.value)}
                  placeholder="0.00"
                  className="mt-2 w-32"
                />
              )}
            </div>

            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="featured"
                  checked={formData.isFeatured || false}
                  onChange={(e) => handleInputChange("isFeatured", e.target.checked)}
                  className="rounded border-gray-300"
                />
                <Label htmlFor="featured">Featured App</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="editorChoice"
                  checked={formData.isEditorChoice || false}
                  onChange={(e) => handleInputChange("isEditorChoice", e.target.checked)}
                  className="rounded border-gray-300"
                />
                <Label htmlFor="editorChoice">Editor's Choice</Label>
              </div>
            </div>
            
            <div>
              <Label>App Icon</Label>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-primary transition-colors cursor-pointer mt-2">
                <Upload className="mx-auto h-8 w-8 text-gray-400 mb-2" />
                <p className="text-gray-600">Click to upload app icon</p>
                <p className="text-sm text-gray-500">PNG, JPG up to 2MB</p>
              </div>
            </div>
            
            <div>
              <Label>App File (APK)</Label>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-primary transition-colors cursor-pointer mt-2">
                <FileArchive className="mx-auto h-8 w-8 text-gray-400 mb-2" />
                <p className="text-gray-600">Click to upload APK file</p>
                <p className="text-sm text-gray-500">APK files up to 100MB</p>
              </div>
            </div>
            
            <div className="flex space-x-4 pt-4">
              <Button
                type="submit"
                disabled={createAppMutation.isPending}
                className="flex-1 bg-primary text-white hover:bg-primary-dark"
              >
                {createAppMutation.isPending ? "Adding..." : "Add App"}
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                className="px-6"
              >
                Cancel
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
