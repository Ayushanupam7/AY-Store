import { Star } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import type { App } from "@shared/schema";

interface AppCardProps {
  app: App;
}

export default function AppCard({ app }: AppCardProps) {
  const renderStars = (rating: number) => {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    
    return (
      <div className="flex text-yellow-400 text-sm mr-2">
        {[...Array(5)].map((_, i) => (
          <Star
            key={i}
            className={`h-3 w-3 ${
              i < fullStars
                ? "fill-current"
                : i === fullStars && hasHalfStar
                ? "fill-current opacity-50"
                : ""
            }`}
          />
        ))}
      </div>
    );
  };

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      Games: "from-blue-500 to-purple-600",
      Business: "from-green-500 to-blue-600",
      Photo: "from-purple-500 to-pink-600",
      Education: "from-yellow-500 to-orange-600",
      Health: "from-green-400 to-blue-500",
      Music: "from-orange-500 to-red-600",
    };
    return colors[category] || "from-gray-500 to-gray-600";
  };

  const getCategoryIcon = (category: string) => {
    const icons: Record<string, string> = {
      Games: "fas fa-gamepad",
      Business: "fas fa-briefcase",
      Photo: "fas fa-camera",
      Education: "fas fa-graduation-cap",
      Health: "fas fa-heartbeat",
      Music: "fas fa-music",
    };
    return icons[category] || "fas fa-mobile-alt";
  };

  return (
    <Card 
      className="hover:shadow-xl transition-all duration-300 cursor-pointer transform hover:-translate-y-1"
      onClick={() => window.location.href = `/app/${app.id}`}
    >
      <CardContent className="p-6">
        <div className="flex items-start mb-4">
          {/* App icon */}
          <div className={`w-16 h-16 bg-gradient-to-br ${getCategoryColor(app.category)} rounded-2xl flex items-center justify-center mr-4 flex-shrink-0`}>
            <i className={`${getCategoryIcon(app.category)} text-white text-2xl`}></i>
          </div>
          <div className="flex-1 min-w-0">
            <h4 className="font-bold text-lg truncate">{app.name}</h4>
            <p className="text-gray-600 text-sm">{app.developer}</p>
            <div className="flex items-center mt-1">
              {renderStars(parseFloat(app.rating))}
              <span className="text-gray-600 text-sm">{app.rating}</span>
            </div>
          </div>
        </div>
        
        <p className="text-gray-700 text-sm mb-4 line-clamp-2">
          {app.description}
        </p>
        
        <div className="flex items-center justify-between">
          <span className={`px-3 py-1 rounded-full text-xs font-medium ${
            app.isFree 
              ? "bg-green-100 text-green-800" 
              : "bg-blue-100 text-blue-800"
          }`}>
            {app.isFree ? "FREE" : `$${app.price}`}
          </span>
          <Button 
            size="sm"
            className="bg-primary text-white hover:bg-primary-dark"
            onClick={(e) => {
              e.stopPropagation();
              // Handle install/buy action
            }}
          >
            {app.isFree ? "Install" : "Buy"}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
