import { useState } from "react";
import { Search, Plus, Menu, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

interface HeaderProps {
  onOpenAdmin: () => void;
}

export default function Header({ onOpenAdmin }: HeaderProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      window.location.href = `/?search=${encodeURIComponent(searchQuery.trim())}`;
    }
  };

  return (
    <>
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <div className="flex items-center">
              <div className="bg-primary rounded-lg p-2 mr-3">
                <i className="fas fa-mobile-alt text-white text-xl"></i>
              </div>
              <h1 className="text-2xl font-bold text-primary cursor-pointer" onClick={() => window.location.href = "/"}>
                AY Store
              </h1>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex space-x-8">
              <a href="/" className="text-neutral-900 hover:text-primary transition-colors">
                Home
              </a>
              <a href="#" className="text-neutral-900 hover:text-primary transition-colors">
                Categories
              </a>
              <a href="#" className="text-neutral-900 hover:text-primary transition-colors">
                Top Charts
              </a>
              <a href="#" className="text-neutral-900 hover:text-primary transition-colors">
                My Apps
              </a>
            </nav>

            {/* Search Bar */}
            <div className="hidden sm:block flex-1 max-w-lg mx-8">
              <form onSubmit={handleSearch}>
                <div className="relative">
                  <Input
                    type="text"
                    placeholder="Search apps & games"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                </div>
              </form>
            </div>

            {/* User Actions */}
            <div className="flex items-center space-x-4">
              <Button
                className="hidden md:flex bg-primary text-white hover:bg-primary-dark"
                onClick={onOpenAdmin}
              >
                <Plus className="h-4 w-4 mr-2" />
                Admin
              </Button>
              <Button variant="ghost" size="sm">
                <User className="h-5 w-5" />
              </Button>
              {/* Mobile menu button */}
              <Button
                variant="ghost"
                size="sm"
                className="md:hidden"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              >
                <Menu className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Navigation Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white border-b shadow-sm">
          <nav className="px-4 py-4 space-y-2">
            <a href="/" className="block py-2 text-neutral-900 hover:text-primary transition-colors">
              Home
            </a>
            <a href="#" className="block py-2 text-neutral-900 hover:text-primary transition-colors">
              Categories
            </a>
            <a href="#" className="block py-2 text-neutral-900 hover:text-primary transition-colors">
              Top Charts
            </a>
            <a href="#" className="block py-2 text-neutral-900 hover:text-primary transition-colors">
              My Apps
            </a>
            <Button
              className="w-full mt-4 bg-primary text-white hover:bg-primary-dark justify-start"
              onClick={onOpenAdmin}
            >
              <Plus className="h-4 w-4 mr-2" />
              Admin Panel
            </Button>
          </nav>
        </div>
      )}
    </>
  );
}
