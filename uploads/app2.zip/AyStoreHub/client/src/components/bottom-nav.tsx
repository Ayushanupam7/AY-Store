import { useState } from "react";
import { Home, Grid3X3, TrendingUp, User } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function BottomNav() {
  const [activeTab, setActiveTab] = useState("home");

  const navItems = [
    { id: "home", icon: Home, label: "Home", href: "/" },
    { id: "categories", icon: Grid3X3, label: "Categories", href: "#" },
    { id: "charts", icon: TrendingUp, label: "Top Charts", href: "#" },
    { id: "profile", icon: User, label: "Profile", href: "#" },
  ];

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-40">
      <div className="flex justify-around py-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          
          return (
            <Button
              key={item.id}
              variant="ghost"
              size="sm"
              className={`flex flex-col items-center p-2 transition-colors ${
                isActive ? "text-primary" : "text-gray-500 hover:text-primary"
              }`}
              onClick={() => {
                setActiveTab(item.id);
                if (item.href !== "#") {
                  window.location.href = item.href;
                }
              }}
            >
              <Icon className="h-5 w-5 mb-1" />
              <span className="text-xs font-medium">{item.label}</span>
            </Button>
          );
        })}
      </div>
    </nav>
  );
}
