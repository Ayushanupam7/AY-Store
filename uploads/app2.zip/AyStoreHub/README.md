# AY Store - Mobile App Store Platform

A fully responsive Play Store-like web application with mobile-first design for app distribution and management.

## Features

- ✅ **Modern React Frontend** with TypeScript and responsive design
- ✅ **Express.js Backend** with RESTful API endpoints
- ✅ **Mobile-First Design** with bottom navigation and touch-friendly UI
- ✅ **App Management** - Admin panel for adding/managing apps
- ✅ **User Reviews** - Rating and review system for apps
- ✅ **Search & Categories** - Browse apps by category or search functionality
- ✅ **In-Memory Storage** - Fast, development-ready data storage

## How to Run in VS Code

### Prerequisites
- Node.js 20+ installed
- VS Code with recommended extensions

### Setup Instructions

1. **Clone/Open the project in VS Code**
   ```bash
   # If cloning from a repository
   git clone <repository-url>
   cd ay-store
   
   # Or open existing folder in VS Code
   code .
   ```

2. **Install Dependencies**
   ```bash
   npm install
   ```

3. **Run the Development Server**
   ```bash
   npm run dev
   ```

4. **Open in Browser**
   - The app will be available at `http://localhost:5000`
   - Frontend and backend run on the same port
   - Hot reload is enabled for development

### VS Code Extensions (Recommended)

- **TypeScript** - Built-in VS Code support
- **ES7+ React/Redux/React-Native snippets** - Code snippets
- **Tailwind CSS IntelliSense** - CSS class autocomplete
- **Thunder Client** - For testing API endpoints
- **Auto Rename Tag** - HTML/JSX tag renaming

### Project Structure

```
ay-store/
├── client/                 # React frontend
│   ├── src/
│   │   ├── components/     # Reusable UI components
│   │   ├── pages/         # Page components
│   │   ├── hooks/         # Custom React hooks
│   │   └── lib/           # Utilities and API client
├── server/                # Express backend
│   ├── index.ts          # Server entry point
│   ├── routes.ts         # API routes
│   ├── storage.ts        # In-memory data storage
│   └── vite.ts           # Vite dev server setup
├── shared/               # Shared types and schemas
│   └── schema.ts         # Database schema and types
└── package.json          # Project dependencies
```

### Available Scripts

- `npm run dev` - Start development server (frontend + backend)
- `npm run build` - Build for production
- `npm run preview` - Preview production build

### API Endpoints

The backend provides these REST endpoints:

- `GET /api/apps` - Get all apps
- `GET /api/apps/featured` - Get featured apps
- `GET /api/apps/top` - Get top-rated apps
- `GET /api/apps/editors-choice` - Get editor's choice apps
- `GET /api/apps/search?q=query` - Search apps
- `GET /api/apps/category/:category` - Get apps by category
- `GET /api/apps/:id` - Get specific app
- `POST /api/apps` - Create new app (admin)
- `GET /api/apps/:id/reviews` - Get app reviews
- `POST /api/apps/:id/reviews` - Add review
- `GET /api/categories` - Get all categories

### Development Tips

1. **Hot Reload**: Changes to frontend files trigger automatic reload
2. **Backend Changes**: Server restarts automatically when backend files change
3. **Debugging**: Use VS Code's built-in debugger or browser dev tools
4. **API Testing**: Use Thunder Client extension or browser to test endpoints

### Troubleshooting

**Port Already in Use:**
```bash
# Kill process on port 5000
npx kill-port 5000
# Then restart
npm run dev
```

**TypeScript Errors:**
- Check the Problems panel in VS Code
- Most errors will be shown with red underlines
- Use Cmd/Ctrl + Shift + P → "TypeScript: Restart TS Server"

**Missing Dependencies:**
```bash
npm install
# Or if package-lock.json is corrupted
rm -rf node_modules package-lock.json
npm install
```

## How to Use the App

1. **Browse Apps**: View featured apps, categories, and top charts
2. **Search**: Use the search bar to find specific apps
3. **App Details**: Click any app to view details, reviews, and ratings
4. **Add Reviews**: Write reviews and rate apps on detail pages
5. **Admin Panel**: Click the "+" button to add new apps (admin feature)
6. **Mobile Navigation**: Use bottom navigation on mobile devices

## Technology Stack

- **Frontend**: React 18, TypeScript, Tailwind CSS, Vite
- **Backend**: Express.js, TypeScript
- **UI Components**: Radix UI primitives with custom styling
- **State Management**: TanStack Query for server state
- **Routing**: Wouter (lightweight React router)
- **Build Tool**: Vite for fast development and optimized builds